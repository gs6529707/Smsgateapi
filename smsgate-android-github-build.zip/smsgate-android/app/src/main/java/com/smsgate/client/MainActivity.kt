package com.smsgate.client

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var server: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var device: EditText
    private lateinit var phone: EditText
    private lateinit var message: EditText
    private lateinit var sim: Spinner
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("gateway", Context.MODE_PRIVATE) }

    // Defaults from the setup shown by the user. Change them in Settings if needed.
    private val DEFAULT_SERVER = "https://api.sms-gate.app"
    private val DEFAULT_USERNAME = "RT-VHQ"
    private val DEFAULT_PASSWORD = "CHANGE_ME"
    private val DEFAULT_DEVICE = "5NcScdWUk__0E2RG0CEWC"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMain()
    }

    private fun cfg(key: String, fallback: String) = prefs.getString(key, fallback) ?: fallback

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(11,18,32))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun title(t: String, size: Float = 22f): TextView = TextView(this).apply {
            text=t; textSize=size; setTextColor(Color.WHITE); setPadding(0,10,0,14)
        }
        fun label(t: String): TextView = TextView(this).apply {
            text=t; textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,12,0,5)
        }
        fun edit(hint: String, value: String = "") = EditText(this).apply {
            this.hint=hint; setText(value); textSize=16f; setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        fun button(t: String) = Button(this).apply { text=t; isAllCaps=false }

        content.addView(title("📱 SMS Gate Client"))
        content.addView(title("Send SMS", 19f))

        content.addView(label("Phone number"))
        phone = edit("+919876543210")
        content.addView(phone)

        content.addView(label("Message"))
        message = edit("Type your SMS...")
        message.minLines = 4
        message.gravity = Gravity.TOP
        content.addView(message)

        content.addView(label("SIM"))
        sim = Spinner(this)
        sim.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("SIM 1","SIM 2"))
        content.addView(sim)

        val send = button("Send SMS")
        content.addView(send)
        send.setOnClickListener { sendSms() }

        content.addView(title("Gateway",19f))
        status = TextView(this).apply { textSize=14f; setTextColor(Color.LTGRAY); setPadding(0,10,0,10) }
        content.addView(status)

        val test = button("Test connection")
        content.addView(test)
        test.setOnClickListener { testConnection() }

        val inbox = button("Refresh inbox")
        content.addView(inbox)
        inbox.setOnClickListener { loadInbox() }

        val settings = button("Gateway settings")
        content.addView(settings)
        settings.setOnClickListener { showSettings() }

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,-1))
        setContentView(root)
    }

    private fun baseUrl(): String {
        var s = cfg("server", DEFAULT_SERVER).trim()
        if (!s.startsWith("http")) s = "https://$s"
        return s.trimEnd('/').removeSuffix(":443")
    }

    private fun authHeader(): String {
        val u = cfg("username", DEFAULT_USERNAME)
        val p = cfg("password", DEFAULT_PASSWORD)
        val raw = "$u:$p"
        return "Basic " + Base64.getEncoder().encodeToString(raw.toByteArray(Charsets.UTF_8))
    }

    private fun request(method: String, path: String, body: String? = null): Pair<Int,String> {
        val url = URL(baseUrl() + "/3rdparty/v1" + path)
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Authorization", authHeader())
        c.setRequestProperty("Content-Type","application/json")
        c.setRequestProperty("Accept","application/json")
        if (body != null) {
            c.doOutput=true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code=c.responseCode
        val stream=if(code in 200..399) c.inputStream else c.errorStream
        val text=stream?.bufferedReader()?.use{it.readText()} ?: ""
        c.disconnect()
        return code to text
    }

    private fun testConnection() {
        status.text="Testing..."
        thread {
            try {
                val (code, body)=request("GET","/devices")
                runOnUiThread {
                    status.text=if(code in 200..299) "✅ Connected. Devices API responded.\n$body"
                    else "❌ HTTP $code\n$body"
                }
            } catch(e: Exception) {
                runOnUiThread { status.text="❌ ${e.javaClass.simpleName}: ${e.message}" }
            }
        }
    }

    private fun sendSms() {
        val to=phone.text.toString().trim()
        val text=message.text.toString().trim()
        if(to.isEmpty() || text.isEmpty()) { status.text="Enter phone number and message."; return }
        status.text="Sending..."
        val simNumber=sim.selectedItemPosition+1
        val deviceId=cfg("device",DEFAULT_DEVICE)
        thread {
            try {
                val payload=JSONObject()
                    .put("textMessage", JSONObject().put("text",text))
                    .put("deviceId",deviceId)
                    .put("phoneNumbers", JSONArray().put(to))
                    .put("simNumber",simNumber)
                    .put("ttl",3600)
                    .put("priority",100)
                val (code,body)=request("POST","/messages?skipPhoneValidation=true&deviceActiveWithin=12",payload.toString())
                runOnUiThread {
                    status.text=if(code in 200..299) "✅ SMS accepted.\n$body" else "❌ HTTP $code\n$body"
                    if(code in 200..299) message.setText("")
                }
            } catch(e: Exception) {
                runOnUiThread { status.text="❌ ${e.javaClass.simpleName}: ${e.message}" }
            }
        }
    }

    private fun loadInbox() {
        status.text="Loading inbox..."
        thread {
            try {
                val (code,body)=request("GET","/inbox")
                runOnUiThread { status.text=if(code in 200..299) "📥 Inbox:\n$body" else "❌ HTTP $code\n$body" }
            } catch(e: Exception) {
                runOnUiThread { status.text="❌ ${e.javaClass.simpleName}: ${e.message}" }
            }
        }
    }

    private fun showSettings() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding=24}
        fun e(v:String)=EditText(this).apply{setText(v);setTextColor(Color.WHITE);setPadding(0,10,0,10)}
        server=e(cfg("server",DEFAULT_SERVER))
        username=e(cfg("username",DEFAULT_USERNAME))
        password=e(cfg("password",DEFAULT_PASSWORD)); password.inputType=129
        device=e(cfg("device",DEFAULT_DEVICE))
        box.addView(TextView(this).apply{text="Cloud server";setTextColor(Color.WHITE)})
        box.addView(server)
        box.addView(TextView(this).apply{text="Username";setTextColor(Color.WHITE)})
        box.addView(username)
        box.addView(TextView(this).apply{text="Password";setTextColor(Color.WHITE)})
        box.addView(password)
        box.addView(TextView(this).apply{text="Device ID";setTextColor(Color.WHITE)})
        box.addView(device)
        val save=Button(this).apply{text="Save & return"}
        box.addView(save)
        val dialog=android.app.AlertDialog.Builder(this).setTitle("Gateway settings").setView(box).create()
        save.setOnClickListener {
            prefs.edit().putString("server",server.text.toString().trim())
                .putString("username",username.text.toString().trim())
                .putString("password",password.text.toString())
                .putString("device",device.text.toString().trim()).apply()
            dialog.dismiss()
            showMain()
        }
        dialog.show()
    }
}
